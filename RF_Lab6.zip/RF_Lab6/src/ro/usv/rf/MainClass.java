 package ro.usv.rf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Random;

public class MainClass {
	
	
	public static void main(String[] args) {
		int MAX_KNN = 17;
		String[][] stringLearningSet;
		double[] toFind = { 3.80, 5.75, 6.25,7.25, 8.5};
		try {
			stringLearningSet = FileUtils.readLearningSetFromFile("C:\\Users\\Florin\\Desktop\\UFLab6\\gradesClasses.txt");
			double[] learningSet = new double[stringLearningSet.length];
			String[] classes = new String[stringLearningSet.length];
			
			for(int i=0; i<stringLearningSet.length;i++) {
				learningSet[i] = Double.valueOf(stringLearningSet[i][0]);
				classes[i] = stringLearningSet[i][1];
			}
			
			
			int numberOfPatterns = stringLearningSet.length;
			int numberOfFeatures = stringLearningSet[0].length;
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
			
			for(int i=0; i<toFind.length;i++) {
				PriorityQueue<Place> pq = new PriorityQueue<Place>(MAX_KNN, Collections.reverseOrder());
				for(int j=0; j<learningSet.length; j++) {
					double distance = DistanceUtils.euclidianDistanceOneDimension(toFind[i], learningSet[j]);
					if(pq.size() <MAX_KNN) {
						pq.add(new Place(stringLearningSet[j], distance));
					} else {
						if(distance < ((Place)pq.peek()).distance) {
							pq.poll();
							pq.add(new Place(stringLearningSet[j], distance));
						}
					}
				}

				List<Place> nearest = new ArrayList<>(MAX_KNN);
				while(pq.size()!=0) {
					Place p = (Place)pq.poll();
					nearest.add(p);
				}
				nearest.sort(Comparator.naturalOrder());
				System.out.println("Pattern: " + toFind[i]);
				for(int k = 1; k<=MAX_KNN; k+=2) {
					writeClass(k, nearest);
				}
			}
			
			
			
			
			//-------------------------------b)--------------------------
			Map<String, Integer> classesMap = new HashMap<String, Integer>();
			
			//create map with distinct classes and number of occurence for each class
			for (int i=0; i<numberOfPatterns; i++)
			{
				String clazz = stringLearningSet[i][stringLearningSet[i].length-1];
				if (classesMap.containsKey(clazz))
				{
					Integer nrOfClassPatterns = classesMap.get(clazz);
					classesMap.put(clazz, nrOfClassPatterns + 1);
				}
				else
				{
					classesMap.put(clazz, 1);
				}
			}
			
			Random random = new Random();
			//map that keeps for each class the random patterns selected for evaluation set
			Map<String, List<Integer>> classesEvaluationPatterns = new HashMap<String, List<Integer>>();
			Integer evaluationSetSize = 0;
			for (Map.Entry<String, Integer> entry: classesMap.entrySet())
			{
				String className = entry.getKey();
				Integer classMembers = entry.getValue();
				Integer evaluationPatternsNr = Math.round(classMembers *15/100);
				evaluationSetSize += evaluationPatternsNr;
				List<Integer> selectedPatternsForEvaluation = new ArrayList<Integer>();
				for (int i=0; i<evaluationPatternsNr; i++)
				{
					Integer patternNr = random.nextInt(classMembers ) +1;
					while (selectedPatternsForEvaluation.contains(patternNr))
					{
						patternNr = random.nextInt(classMembers ) +1;
					}
					selectedPatternsForEvaluation.add(patternNr);
				}
				classesEvaluationPatterns.put(className, selectedPatternsForEvaluation);				
			}
			
			String[][] evaluationSet = new String[evaluationSetSize][numberOfPatterns];
			String[][] trainingSet = new String[numberOfPatterns-evaluationSetSize][numberOfPatterns];
			int evaluationSetIndex = 0;
			int trainingSetIndex = 0;
			Map<String, Integer> classCurrentIndex = new HashMap<String, Integer>();
			for (int i=0; i<numberOfPatterns; i++)
			{
				String className = stringLearningSet[i][numberOfFeatures-1];
				if (classCurrentIndex.containsKey(className))
				{
					int currentIndex = classCurrentIndex.get(className);
					classCurrentIndex.put(className, currentIndex+1);
				}
				else
				{
					classCurrentIndex.put(className, 1);
				}
				if (classesEvaluationPatterns.get(className).contains(classCurrentIndex.get(className)))
				{
					evaluationSet[evaluationSetIndex] = stringLearningSet[i];
					evaluationSetIndex++;
				}
				else
				{
					trainingSet[trainingSetIndex] = stringLearningSet[i];
					trainingSetIndex++;
				}
			}
			
			
			for(int k=1; k<45;k+=2) {
				
			}
			
			
			
			
			
			
			
			
			
			
			
		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
	}
	
	private static void writeClass(int neighboursNumber, List<Place> nearest) {
		System.out.print(neighboursNumber + " neighbours: ");
		HashMap<String, Integer> nearestMap = new HashMap<>();
		for(int j=0; j<neighboursNumber;j++) {
			Place peek = nearest.get(j);
			String name = peek.pattern[peek.pattern.length -1];
			if(!nearestMap.containsKey(name)) {
				nearestMap.put(name, 0);
			}
			nearestMap.put(name, nearestMap.get(name) +1);
		}
		
		System.out.println(Collections.max(nearestMap.entrySet(), (entry1, entry2) -> entry1.getValue() - entry2.getValue()).getKey());
	}

}
